
// Namespace our translation keys to avoid conflicts and better organization
export type TranslationNamespace = 
  | 'common'
  | 'crypto'
  | 'wallet'
  | 'security'
  | 'ui';

// Types for each namespace
export type CommonTranslationKey =
  | 'loading'
  | 'error'
  | 'success'
  | 'confirm'
  | 'cancel'
  | 'save'
  | 'edit'
  | 'delete'
  | 'back'
  | 'next'
  | 'low'
  | 'medium'
  | 'high';

export type CryptoTranslationKey =
  | "cryptoTechnologies"
  | "securityLevel"
  | "encryptionStatus"
  | "dataProtection"
  | "encrypt"
  | "decrypt"
  | "encryptData"
  | "decryptData"
  | "encryptDescription"
  | "decryptDescription"
  | "inputData"
  | "enterText"
  | "encryptionNotice"
  | "encryptButton"
  | "decryptButton"
  | "noEncryptedData"
  | "decryptedResult"
  | "keysGenerated"
  | "generatingKeys"
  | "dataEncrypted"
  | "dataNotEncrypted"
  | "initializingCrypto"
  | "generatingSecureKeys"
  | "processingData"
  | "applyingEncryption"
  | "decryptingData"
  | "verifyingIntegrity"
  | "secureCommunication"
  | "cryptoShielding"
  | "crossChainSecurity"
  | "privateKeyStorage"
  | "seedPhrase"
  | "advancedEncryption"
  | "hashingAlgorithm"
  | "signatureVerification"
  | "networkSecurity"
  | "aiCryptoShield";

export type WalletTranslationKey = 
  | "walletIntegration"
  | "connectWallet"
  | "disconnectWallet"
  | "walletConnected"
  | "walletDisconnected"
  | "selectWallet"
  | "metamask"
  | "trustWallet"
  | "phantom"
  | "walletConnect"
  | "walletBalances"
  | "walletAddress"
  | "walletNetwork"
  | "walletTransactions"
  | "walletTokens"
  | "walletHistory"
  | "walletSend"
  | "walletReceive"
  | "walletExchange"
  | "walletSecurity"
  | "confirmTransaction"
  | "transactionPending"
  | "send"
  | "yourWallet"
  | "connected"
  | "disconnected"
  | "connecting"
  | "connectError"
  | "disconnect"
  | "balance"
  | "ethereum"
  | "solana"
  | "multiChain"
  | "mobileWallets"
  | "refresh"
  | "receive"
  | "swap"
  | "terms"
  | "noWallet"
  | "learnMore"
  | "activeStatus"
  | "yourBalance"
  | "quickActions"
  | "recentActivity"
  | "viewAllTransactions"
  | "today"
  | "yesterday"
  | "balanceRefreshed"
  | "balanceUpdated"
  | "refreshFailed"
  | "couldNotRefresh"
  | "connectionFailed"
  | "couldNotConnect"
  | "pleaseTryAgain"
  | "errorConnecting"
  | "walletDisconnectedDesc"
  | "successfullyConnected"
  | "termsNotice"
  | "connectYourWallet"
  | "connectToEthereum"
  | "connectToSolana"
  | "multiChainSupport";

export type SecurityTranslationKey =
  | "securityFeatures"
  | "quantumResistant"
  | "multiChain"
  | "languageSupport"
  | "keyManagement"
  | "securityAssessment"
  | "cryptoWorkflow"
  | "secureProtocol"
  | "twofactorAuth"
  | "biometricProtection"
  | "fraudPrevention"
  | "riskAssessment"
  | "securityScore"
  | "multiLayerSecurity"
  | "threatDetection"
  | "privacyMeasures"
  | "dataIsolation";

export type UITranslationKey =
  | "darkMode"
  | "lightMode"
  | "settings"
  | "profile"
  | "logout"
  | "login"
  | "register"
  | "search"
  | "notifications"
  | "menu"
  | "close"
  | "open"
  | "multilingual"
  | "layoutSettings"
  | "appearance"
  | "accessibility"
  | "fontSize"
  | "animationSpeed"
  | "colorScheme"
  | "themeSelection"
  | "interfaceLanguage"
  | "displayPreferences";

// Translation record type that includes all namespaces and their keys
export type TranslationRecord = {
  common: Record<CommonTranslationKey, string>;
  crypto: Record<CryptoTranslationKey, string>;
  wallet: Record<WalletTranslationKey, string>;
  security: Record<SecurityTranslationKey, string>;
  ui: Record<UITranslationKey, string>;
};
