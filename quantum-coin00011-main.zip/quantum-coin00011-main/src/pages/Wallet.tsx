
import { useState } from "react";
import { NavBar } from "@/components/layout/NavBar";
import { Footer } from "@/components/layout/Footer";
import WalletCard from "@/components/wallet/WalletCard";
import { useWallet } from "@/hooks/use-wallet";
import { Globe } from "lucide-react";
import { languages } from "@/lib/translations/languages";

export default function Wallet() {
  const { currentLanguage, setLanguage, connectToWallet, walletType } = useWallet();
  const [showLanguageSelector, setShowLanguageSelector] = useState(false);
  
  // Default values for NavBar props
  const [showCharts, setShowCharts] = useState(false);
  const [showAIChat, setShowAIChat] = useState(false);
  const [showSwap, setShowSwap] = useState(false);
  
  const getLanguageName = (code: string) => {
    return languages.find(lang => lang.code === code)?.name || code.toUpperCase();
  };
  
  const handleLanguageChange = (language: string) => {
    setLanguage(language);
    setShowLanguageSelector(false);
  };
  
  // Handle NavBar actions
  const handleLogoClick = () => {
    // Navigate to home or refresh
    window.location.href = '/';
  };
  
  const handleConnectWallet = (walletType: string) => {
    connectToWallet(walletType as any);
  };
  
  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-purple-900 to-gray-900">
      <NavBar 
        logoType="gem"
        onLogoClick={handleLogoClick}
        selectedWallet={walletType || null}
        onConnectWallet={handleConnectWallet}
        onShowCharts={() => setShowCharts(!showCharts)}
        onShowAIChat={() => setShowAIChat(!showAIChat)}
        onShowSwap={() => setShowSwap(!showSwap)}
        showCharts={showCharts}
        showAIChat={showAIChat}
        showSwap={showSwap}
      />
      
      <main className="pt-32 pb-20">
        <div className="container mx-auto px-6">
          <div className="max-w-md mx-auto">
            <WalletCard />
          </div>
        </div>
      </main>
      
      <div className="fixed bottom-6 right-6 z-10">
        <div className="relative">
          <button 
            onClick={() => setShowLanguageSelector(!showLanguageSelector)} 
            className="bg-black/60 border border-purple-500/30 rounded-full p-2 flex items-center gap-1 text-xs text-white"
          >
            <Globe className="h-3 w-3 text-purple-400" />
            <span>{getLanguageName(currentLanguage)}</span>
          </button>
          
          {showLanguageSelector && (
            <div className="absolute right-0 bottom-10 bg-gray-800 rounded-md shadow-lg p-2 z-10 max-h-40 overflow-y-auto">
              {languages.map((lang) => (
                <button
                  key={lang.code}
                  className={`block w-full text-left px-3 py-1 text-sm rounded-sm ${
                    currentLanguage === lang.code ? 'bg-purple-600 text-white' : 'text-gray-300 hover:bg-gray-700'
                  }`}
                  onClick={() => handleLanguageChange(lang.code)}
                >
                  {lang.name}
                </button>
              ))}
            </div>
          )}
        </div>
      </div>
      
      <Footer />
    </div>
  );
}
