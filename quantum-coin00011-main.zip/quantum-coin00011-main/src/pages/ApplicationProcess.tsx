import React, { useState, useEffect } from "react";
import { Logo } from "@/components/layout/Logo";
import { Check, ChevronRight, FileText, Users, ArrowLeft, Send, Layers, Pickaxe, FileCheck, LogIn, LogOut, Wand2 } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import applicationService, { ApplicationData, UserData, LoginData } from "@/services/applicationService";
import aiService from "@/services/aiService";
import { toast } from "sonner";

export default function ApplicationProcess() {
  const [currentStep, setCurrentStep] = useState(0);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");
  const [stackingAmount, setStackingAmount] = useState("");
  const [miningExperience, setMiningExperience] = useState("");
  const [projectDescription, setProjectDescription] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isGenerating, setIsGenerating] = useState(false);
  const [user, setUser] = useState<UserData | null>(null);
  const { toast: useToastToast } = useToast();

  useEffect(() => {
    const currentUser = applicationService.getCurrentUser();
    if (currentUser) {
      setUser(currentUser);
      setCurrentStep(1);
      setEmail(currentUser.email);
      setName(currentUser.name);
    }
  }, []);

  const steps = [
    {
      number: 0,
      title: "Login",
      description: "Sign in to your account",
      icon: <LogIn className="w-4 h-4" />
    },
    {
      number: 1,
      title: "Basic Information",
      description: "Tell us about yourself",
      icon: <Users className="w-4 h-4" />
    },
    {
      number: 2,
      title: "Stacking Details",
      description: "QuantumCoin stacking preferences",
      icon: <Layers className="w-4 h-4" />
    },
    {
      number: 3,
      title: "Mining Experience",
      description: "Share your mining background",
      icon: <Pickaxe className="w-4 h-4" />
    },
    {
      number: 4,
      title: "Project Details",
      description: "Describe your blockchain project",
      icon: <FileText className="w-4 h-4" />
    },
    {
      number: 5,
      title: "Review & Submit",
      description: "Confirm your application",
      icon: <FileCheck className="w-4 h-4" />
    },
    {
      number: 6,
      title: "Application Complete",
      description: "We'll be in touch soon",
      icon: <Check className="w-4 h-4" />
    }
  ];

  const handleLogin = async () => {
    setIsSubmitting(true);
    
    try {
      const loginData: LoginData = {
        email,
        password
      };
      
      const userData = await applicationService.login(loginData);
      
      if (userData) {
        setUser(userData);
        setCurrentStep(1);
        setName(userData.name);
      }
    } catch (error) {
      console.error("Login error:", error);
      toast.error("Login failed. Please try again.");
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleLogout = () => {
    applicationService.logout();
    setUser(null);
    setCurrentStep(0);
    setPassword("");
  };

  const handleSubmit = async () => {
    setIsSubmitting(true);
    
    const applicationData: ApplicationData = {
      name,
      email,
      stackingAmount,
      miningExperience,
      projectDescription,
      submittedAt: new Date().toISOString()
    };
    
    try {
      const success = await applicationService.submitApplication(applicationData);
      
      if (success) {
        setCurrentStep(6);
        useToastToast({
          title: "Application Submitted",
          description: "We'll review your application and contact you soon.",
        });
      }
    } catch (error) {
      console.error("Error submitting application:", error);
      toast.error("There was a problem submitting your application. Please try again.");
    } finally {
      setIsSubmitting(false);
    }
  };

  const generateAIText = async (fieldType: 'stackingAmount' | 'miningExperience' | 'projectDescription') => {
    setIsGenerating(true);
    
    try {
      let prompt = '';
      
      switch (fieldType) {
        case 'stackingAmount':
          prompt = 'Generate a detailed description of stacking QuantumCoins';
          break;
        case 'miningExperience':
          prompt = 'Generate a detailed description of cryptocurrency mining experience';
          break;
        case 'projectDescription':
          prompt = 'Generate a detailed description of a blockchain project that could use QuantumCoin';
          break;
      }
      
      const response = await aiService.generateText({ prompt });
      
      if (response.status === 'success') {
        switch (fieldType) {
          case 'stackingAmount':
            setStackingAmount(response.text);
            break;
          case 'miningExperience':
            setMiningExperience(response.text);
            break;
          case 'projectDescription':
            setProjectDescription(response.text);
            break;
        }
        toast.success('AI-generated text added!');
      } else {
        toast.error(response.message || 'Failed to generate text');
      }
    } catch (error) {
      console.error('Error generating text:', error);
      toast.error('Something went wrong with AI generation');
    } finally {
      setIsGenerating(false);
    }
  };

  const renderStepContent = () => {
    switch (currentStep) {
      case 0:
        return (
          <div className="space-y-4">
            <h3 className="text-xl font-bold text-white">Sign in to SietkCoin</h3>
            <p className="text-gray-300 mb-4">Enter your credentials to continue</p>
            <div className="space-y-2">
              <label htmlFor="login-email" className="block text-sm font-medium text-gray-200">Email Address</label>
              <Input 
                id="login-email" 
                type="email" 
                value={email} 
                onChange={(e) => setEmail(e.target.value)} 
                placeholder="Enter your email address"
                className="bg-black/30 border-purple-500/30 text-white"
              />
            </div>
            <div className="space-y-2">
              <label htmlFor="login-password" className="block text-sm font-medium text-gray-200">Password</label>
              <Input 
                id="login-password" 
                type="password" 
                value={password} 
                onChange={(e) => setPassword(e.target.value)} 
                placeholder="Enter your password"
                className="bg-black/30 border-purple-500/30 text-white"
              />
            </div>
            <button 
              onClick={handleLogin} 
              disabled={!email || !password || isSubmitting}
              className="w-full mt-6 bg-purple-500 hover:bg-purple-600 disabled:bg-purple-500/50 disabled:cursor-not-allowed transition-colors px-6 py-3 rounded-lg text-white font-medium inline-flex items-center justify-center gap-2"
            >
              {isSubmitting ? "Signing in..." : (
                <>Sign in <LogIn className="w-4 h-4" /></>
              )}
            </button>
            <div className="mt-4 text-center">
              <p className="text-gray-400 text-sm">
                For demo, use any email with password: "password"
              </p>
            </div>
          </div>
        );
      case 1:
        return (
          <div className="space-y-4">
            <div className="space-y-2">
              <label htmlFor="name" className="block text-sm font-medium text-gray-200">Full Name</label>
              <Input 
                id="name" 
                value={name} 
                onChange={(e) => setName(e.target.value)} 
                placeholder="Enter your full name"
                className="bg-black/30 border-purple-500/30 text-white"
              />
            </div>
            <div className="space-y-2">
              <label htmlFor="email" className="block text-sm font-medium text-gray-200">Email Address</label>
              <Input 
                id="email" 
                type="email" 
                value={email} 
                onChange={(e) => setEmail(e.target.value)} 
                placeholder="Enter your email address"
                className="bg-black/30 border-purple-500/30 text-white"
                readOnly={!!user}
              />
            </div>
            <button 
              onClick={() => setCurrentStep(2)} 
              disabled={!name || !email}
              className="w-full mt-6 bg-purple-500 hover:bg-purple-600 disabled:bg-purple-500/50 disabled:cursor-not-allowed transition-colors px-6 py-3 rounded-lg text-white font-medium inline-flex items-center justify-center gap-2"
            >
              Next Step <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        );
      case 2:
        return (
          <div className="space-y-4">
            <div className="space-y-2">
              <label htmlFor="stacking-amount" className="block text-sm font-medium text-gray-200">Stacking Amount</label>
              <div className="relative">
                <Input 
                  id="stacking-amount" 
                  value={stackingAmount} 
                  onChange={(e) => setStackingAmount(e.target.value)} 
                  placeholder="How many QuantumCoins would you like to stack?"
                  className="bg-black/30 border-purple-500/30 text-white pr-12"
                />
                <button
                  type="button"
                  onClick={() => generateAIText('stackingAmount')}
                  disabled={isGenerating}
                  className="absolute right-2 top-1/2 -translate-y-1/2 text-purple-400 hover:text-purple-300 disabled:text-purple-700"
                  title="Generate with AI"
                >
                  <Wand2 className="w-5 h-5" />
                </button>
              </div>
            </div>
            <div className="space-y-2">
              <p className="text-sm text-gray-300">
                Stacking QuantumCoins provides network security and earns rewards. The minimum stacking period is 30 days, with higher rewards for longer commitment periods.
              </p>
            </div>
            <div className="flex gap-3">
              <button 
                onClick={() => setCurrentStep(1)} 
                className="w-1/2 mt-6 bg-black/40 hover:bg-black/60 transition-colors px-6 py-3 rounded-lg text-white font-medium inline-flex items-center justify-center gap-2 border border-purple-500/30"
              >
                <ArrowLeft className="w-4 h-4" /> Back
              </button>
              <button 
                onClick={() => setCurrentStep(3)}
                disabled={!stackingAmount}
                className="w-1/2 mt-6 bg-purple-500 hover:bg-purple-600 disabled:bg-purple-500/50 disabled:cursor-not-allowed transition-colors px-6 py-3 rounded-lg text-white font-medium inline-flex items-center justify-center gap-2"
              >
                Next Step <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        );
      case 3:
        return (
          <div className="space-y-4">
            <div className="space-y-2">
              <label htmlFor="mining-experience" className="block text-sm font-medium text-gray-200">Mining Experience</label>
              <div className="relative">
                <textarea 
                  id="mining-experience" 
                  value={miningExperience}
                  onChange={(e) => setMiningExperience(e.target.value)}
                  placeholder="Describe your cryptocurrency mining experience (if any). Include hardware, pools, and duration."
                  className="w-full h-40 bg-black/30 border border-purple-500/30 text-white rounded-md p-3 resize-none focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent pr-12"
                />
                <button
                  type="button"
                  onClick={() => generateAIText('miningExperience')}
                  disabled={isGenerating}
                  className="absolute right-3 top-3 text-purple-400 hover:text-purple-300 disabled:text-purple-700"
                  title="Generate with AI"
                >
                  <Wand2 className="w-5 h-5" />
                </button>
              </div>
            </div>
            <div className="flex gap-3">
              <button 
                onClick={() => setCurrentStep(2)} 
                className="w-1/2 mt-6 bg-black/40 hover:bg-black/60 transition-colors px-6 py-3 rounded-lg text-white font-medium inline-flex items-center justify-center gap-2 border border-purple-500/30"
              >
                <ArrowLeft className="w-4 h-4" /> Back
              </button>
              <button 
                onClick={() => setCurrentStep(4)}
                className="w-1/2 mt-6 bg-purple-500 hover:bg-purple-600 disabled:bg-purple-500/50 disabled:cursor-not-allowed transition-colors px-6 py-3 rounded-lg text-white font-medium inline-flex items-center justify-center gap-2"
              >
                Next Step <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        );
      case 4:
        return (
          <div className="space-y-4">
            <div className="space-y-2">
              <label htmlFor="project-desc" className="block text-sm font-medium text-gray-200">Project Description</label>
              <div className="relative">
                <textarea 
                  id="project-desc" 
                  value={projectDescription}
                  onChange={(e) => setProjectDescription(e.target.value)}
                  placeholder="Describe your blockchain project and how you plan to use QuantumCoin"
                  className="w-full h-40 bg-black/30 border border-purple-500/30 text-white rounded-md p-3 resize-none focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent pr-12"
                />
                <button
                  type="button"
                  onClick={() => generateAIText('projectDescription')}
                  disabled={isGenerating}
                  className="absolute right-3 top-3 text-purple-400 hover:text-purple-300 disabled:text-purple-700"
                  title="Generate with AI"
                >
                  <Wand2 className="w-5 h-5" />
                </button>
              </div>
            </div>
            <div className="flex gap-3">
              <button 
                onClick={() => setCurrentStep(3)} 
                className="w-1/2 mt-6 bg-black/40 hover:bg-black/60 transition-colors px-6 py-3 rounded-lg text-white font-medium inline-flex items-center justify-center gap-2 border border-purple-500/30"
              >
                <ArrowLeft className="w-4 h-4" /> Back
              </button>
              <button 
                onClick={() => setCurrentStep(5)}
                disabled={!projectDescription}
                className="w-1/2 mt-6 bg-purple-500 hover:bg-purple-600 disabled:bg-purple-500/50 disabled:cursor-not-allowed transition-colors px-6 py-3 rounded-lg text-white font-medium inline-flex items-center justify-center gap-2"
              >
                Review <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        );
      case 5:
        return (
          <div className="space-y-6">
            <h3 className="text-xl font-bold text-white">Review Your Application</h3>
            <div className="bg-black/20 p-4 rounded-lg border border-purple-500/20">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-sm text-gray-400">Full Name</p>
                  <p className="text-white">{name}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-400">Email</p>
                  <p className="text-white">{email}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-400">Stacking Amount</p>
                  <p className="text-white">{stackingAmount}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-400">Mining Experience</p>
                  <p className="text-white whitespace-pre-wrap">{miningExperience || "None provided"}</p>
                </div>
                <div className="col-span-2 mt-2">
                  <p className="text-sm text-gray-400">Project Description</p>
                  <p className="text-white whitespace-pre-wrap">{projectDescription}</p>
                </div>
              </div>
            </div>
            <div className="flex gap-3">
              <button 
                onClick={() => setCurrentStep(4)} 
                className="w-1/2 mt-2 bg-black/40 hover:bg-black/60 transition-colors px-6 py-3 rounded-lg text-white font-medium inline-flex items-center justify-center gap-2 border border-purple-500/30"
              >
                <ArrowLeft className="w-4 h-4" /> Edit
              </button>
              <button 
                onClick={handleSubmit}
                disabled={isSubmitting}
                className="w-1/2 mt-2 bg-purple-500 hover:bg-purple-600 disabled:bg-purple-500/70 transition-colors px-6 py-3 rounded-lg text-white font-medium inline-flex items-center justify-center gap-2"
              >
                {isSubmitting ? (
                  <>Submitting...</>
                ) : (
                  <>Submit Application <Send className="w-4 h-4" /></>
                )}
              </button>
            </div>
          </div>
        );
      case 6:
        return (
          <div className="text-center space-y-6">
            <div className="w-16 h-16 bg-purple-500/20 rounded-full flex items-center justify-center mx-auto">
              <Check className="w-8 h-8 text-purple-400" />
            </div>
            <h3 className="text-xl font-bold text-white">Application Submitted!</h3>
            <p className="text-gray-300">
              Thank you for your interest in SietkCoin. Our team will review your application and get back to you within 2-3 business days.
            </p>
            <button 
              onClick={() => window.location.href = "/"}
              className="mt-6 bg-purple-500 hover:bg-purple-600 transition-colors px-8 py-3 rounded-lg text-white font-medium inline-flex items-center justify-center gap-2"
            >
              Return to Homepage
            </button>
          </div>
        );
      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-purple-900 to-gray-900">
      <header className="fixed top-0 left-0 right-0 z-50 bg-black/20 backdrop-blur-lg border-b border-white/10">
        <div className="container mx-auto px-6 py-4">
          <div className="flex justify-between items-center">
            <div className="flex items-center gap-4">
              <Logo />
              <span className="text-xl font-bold text-white">SietkCoin</span>
            </div>
            <div className="flex items-center gap-4">
              {user && (
                <div className="hidden md:flex items-center gap-2 text-gray-300">
                  <span>Logged in as {user.name}</span>
                  <button 
                    onClick={handleLogout}
                    className="text-gray-300 hover:text-white flex items-center gap-1"
                  >
                    <LogOut className="w-4 h-4" /> Logout
                  </button>
                </div>
              )}
              <a 
                href="/"
                className="text-gray-200 hover:text-white transition-colors px-4 py-2"
              >
                Back to Home
              </a>
            </div>
          </div>
        </div>
      </header>

      <main className="pt-32 pb-20">
        <div className="container mx-auto px-6">
          <div className="max-w-4xl mx-auto">
            <h1 className="text-3xl font-bold text-white mb-2">SietkCoin Application</h1>
            <p className="text-gray-300 mb-10">Join the SietkCoin ecosystem and bring your blockchain projects to life.</p>
            
            <div className="mb-10">
              <ol className="flex flex-wrap gap-2">
                {steps.map((step) => (
                  <li key={step.number} className="flex-1 min-w-[150px]">
                    <div 
                      className={`rounded-lg p-4 ${
                        currentStep === step.number 
                          ? 'bg-purple-500/20 border border-purple-500'
                          : currentStep > step.number
                            ? 'bg-green-500/10 border border-green-500/50'
                            : 'bg-black/20 border border-white/10'
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <div 
                          className={`w-8 h-8 rounded-full flex items-center justify-center ${
                            currentStep === step.number 
                              ? 'bg-purple-500 text-white'
                              : currentStep > step.number
                                ? 'bg-green-500 text-white'
                                : 'bg-black/40 text-gray-300'
                          }`}
                        >
                          {currentStep > step.number ? <Check className="w-4 h-4" /> : step.icon}
                        </div>
                        <div>
                          <h3 className="text-sm font-medium text-white">{step.title}</h3>
                          <p className="text-xs text-gray-400">{step.description}</p>
                        </div>
                      </div>
                    </div>
                  </li>
                ))}
              </ol>
            </div>
            
            <Card className="bg-black/40 border-purple-500/30 shadow-xl">
              <CardContent className="p-8">
                {renderStepContent()}
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <footer className="py-12 bg-black/40">
        <div className="container mx-auto px-6">
          <div className="flex justify-between items-center">
            <div className="flex items-center gap-4">
              <Logo />
              <span className="text-white font-medium">SietkCoin</span>
            </div>
            <div className="text-gray-400">
              © 2025 SietkCoin. All rights reserved.
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
