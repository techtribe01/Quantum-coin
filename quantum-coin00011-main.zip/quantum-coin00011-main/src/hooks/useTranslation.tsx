
import { useState, useCallback, useEffect } from 'react';
import { 
  TranslationNamespace, 
  getTranslationByNamespace, 
  getLanguageCode, 
  getLanguageName 
} from '@/lib/translations';

export type TranslationResult = {
  t: (namespace: TranslationNamespace, key: string) => string;
  currentLanguage: string;
  setLanguage: (language: string) => void;
  getLanguageName: (code: string) => string;
  getLanguageCode: (name: string) => string;
};

export function useTranslation(initialLanguage: string = 'en'): TranslationResult {
  // Store language in state
  const [currentLanguage, setCurrentLanguage] = useState<string>(initialLanguage);

  // Effect to persist language preference
  useEffect(() => {
    // Try to get saved language from localStorage
    const savedLanguage = localStorage.getItem('app-language');
    if (savedLanguage) {
      setCurrentLanguage(savedLanguage);
    }
  }, []);

  // Set language and persist to localStorage
  const setLanguage = useCallback((language: string) => {
    setCurrentLanguage(language);
    localStorage.setItem('app-language', language);
  }, []);

  // Translation function
  const t = useCallback(
    (namespace: TranslationNamespace, key: string): string => {
      return getTranslationByNamespace(currentLanguage, namespace, key);
    },
    [currentLanguage]
  );

  return { 
    t,
    currentLanguage,
    setLanguage,
    getLanguageName,
    getLanguageCode
  };
}
