
import { useState, useEffect } from "react";
import { NavBar } from "@/components/layout/NavBar";
import { Footer } from "@/components/layout/Footer";
import { MainContent } from "@/components/home/MainContent";
import { SwapSection } from "@/components/home/SwapSection";
import { ChartsSection } from "@/components/home/ChartsSection";
import { AIChat } from "@/components/chat/AIChat";
import { toast } from "sonner";
import { LogoIconType } from "@/components/layout/Logo";
import exchangeService, { TokenPrice } from "@/services/exchangeService";
import { WalletConnect } from "@/components/wallet/WalletConnect";
import { Globe } from "lucide-react";
import { useTranslationContext } from "@/contexts/TranslationContext";

export default function Index() {
  const { currentLanguage, setLanguage, getLanguageName } = useTranslationContext();
  
  // State variables
  const [showSwap, setShowSwap] = useState(false);
  const [showAIChat, setShowAIChat] = useState(false);
  const [showCharts, setShowCharts] = useState(false);
  const [activeTab, setActiveTab] = useState("overview");
  const [logoType, setLogoType] = useState<LogoIconType>("lion");
  const [selectedWallet, setSelectedWallet] = useState<string | null>(null);
  const [prices, setPrices] = useState<TokenPrice[]>([]);
  const [selectedToken, setSelectedToken] = useState("QNTM");
  const [isLoadingPrices, setIsLoadingPrices] = useState(false);
  const [showWalletDetails, setShowWalletDetails] = useState(false);

  // Price data fetching
  useEffect(() => {
    const fetchPrices = async () => {
      setIsLoadingPrices(true);
      
      // Demonstrate crypto.subtle usage for data integrity verification
      const verifyDataIntegrity = async (data: string) => {
        try {
          // Create a hash of the data for integrity verification
          const encoder = new TextEncoder();
          const dataBuffer = encoder.encode(data);
          const hashBuffer = await crypto.subtle.digest('SHA-256', dataBuffer);
          
          // Convert hash to hex string for logging
          const hashArray = Array.from(new Uint8Array(hashBuffer));
          const hashHex = hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
          
          console.log("Data integrity verified with hash:", hashHex.substring(0, 10) + "...");
          return true;
        } catch (error) {
          console.error("Data integrity verification failed:", error);
          return false;
        }
      };
      
      try {
        const tokenPrices = await exchangeService.getPrices(['ETH', 'BTC', 'USDT', 'SOL', 'QNTM']);
        
        // Verify data integrity
        await verifyDataIntegrity(JSON.stringify(tokenPrices));
        
        setPrices(tokenPrices);
      } catch (error) {
        console.error("Error fetching prices:", error);
        toast.error("Failed to fetch latest prices");
      } finally {
        setIsLoadingPrices(false);
      }
    };
    
    fetchPrices();
    
    const intervalId = setInterval(fetchPrices, 30000);
    
    return () => clearInterval(intervalId);
  }, []);

  // Event handlers
  const handleLogoClick = () => {
    const types: LogoIconType[] = ["lion", "gem", "coins", "diamond"];
    const currentIndex = types.indexOf(logoType);
    const nextIndex = (currentIndex + 1) % types.length;
    setLogoType(types[nextIndex]);
  };

  const handleConnectWallet = (walletType: string) => {
    if (!walletType) {
      setSelectedWallet(null);
      setShowWalletDetails(false);
      return;
    }
    
    setSelectedWallet(walletType);
    // In a real implementation, this would initiate the wallet connection through blockchain APIs
    toast.success(`Connected to ${walletType}`, {
      description: "Your wallet is now connected using quantum-resistant encryption"
    });
  };

  const handleShowCharts = () => {
    setShowCharts(!showCharts);
    setShowAIChat(false);
    setShowSwap(false);
    setShowWalletDetails(false);
  };

  const handleShowAIChat = () => {
    setShowAIChat(!showAIChat);
    setShowSwap(false);
    setShowCharts(false);
    setShowWalletDetails(false);
  };

  const handleShowSwap = () => {
    setShowSwap(!showSwap);
    setShowAIChat(false);
    setShowCharts(false);
    setShowWalletDetails(false);
  };
  
  const toggleWalletDetails = () => {
    setShowWalletDetails(!showWalletDetails);
    setShowSwap(false);
    setShowAIChat(false);
    setShowCharts(false);
  };
  
  const handleLanguageChange = (language: string) => {
    setLanguage(language);
    toast.success(`Application language changed to ${getLanguageName(language)}`);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-purple-900 to-gray-900">
      <NavBar 
        logoType={logoType}
        onLogoClick={handleLogoClick}
        selectedWallet={selectedWallet}
        onConnectWallet={handleConnectWallet}
        onShowCharts={handleShowCharts}
        onShowAIChat={handleShowAIChat}
        onShowSwap={handleShowSwap}
        showCharts={showCharts}
        showAIChat={showAIChat}
        showSwap={showSwap}
      />

      <main className="pt-32 pb-20">
        <div className="container mx-auto px-6">
          {showWalletDetails && selectedWallet ? (
            <div className="flex justify-center">
              <WalletConnect onConnect={handleConnectWallet} selectedWallet={selectedWallet} />
            </div>
          ) : showSwap ? (
            <SwapSection prices={prices} selectedToken={selectedToken} />
          ) : showAIChat ? (
            <div className="flex justify-center">
              <AIChat />
            </div>
          ) : showCharts ? (
            <ChartsSection prices={prices} />
          ) : (
            <MainContent 
              activeTab={activeTab} 
              setActiveTab={setActiveTab} 
              onTrySwap={() => setShowSwap(true)} 
            />
          )}
          
          {selectedWallet && !showWalletDetails && (
            <div className="fixed bottom-20 right-6">
              <button 
                onClick={toggleWalletDetails}
                className="bg-purple-600 text-white p-3 rounded-full shadow-lg hover:bg-purple-700 transition-colors"
                title="View wallet details"
              >
                <WalletConnect onConnect={handleConnectWallet} selectedWallet={selectedWallet} />
              </button>
            </div>
          )}
        </div>
      </main>

      <div className="fixed bottom-6 right-6 z-10">
        <div className="bg-black/60 border border-purple-500/30 rounded-full p-2 flex items-center gap-1 text-xs text-white">
          <Globe className="h-3 w-3 text-purple-400" />
          <span>{getLanguageName(currentLanguage)}</span>
        </div>
      </div>

      <Footer />
    </div>
  );
}
