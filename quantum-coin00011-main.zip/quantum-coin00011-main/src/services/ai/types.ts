
export interface AIGenerationRequest {
  prompt: string;
  context?: string;
  maxLength?: number;
  feature?: QuantumCoinFeature;
  neuralAnalysis?: boolean;
}

export interface AIGenerationResponse {
  text: string;
  status: 'success' | 'error';
  message?: string;
  neuralOutput?: NeuralNetworkOutput;
}

export type QuantumCoinFeature = 'project' | 'mining' | 'stacking' | 'governance' | 'tokenomics' | 'defi' | 'nft';

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant' | 'system';
  content: string | { 
    text: string; 
    charts?: ChartData[] 
  };
  timestamp: Date;
}

export interface ChartData {
  type: 'line' | 'bar' | 'area';
  title: string;
  data: any[];
  xAxisKey: string;
  yAxisKey: string;
  color?: string;
}

export interface NeuralNetworkOutput {
  confidence: number;
  vectorEmbedding?: number[];
  classification?: string;
  securityScore?: number;
  anomalyDetection?: {
    isAnomaly: boolean;
    score: number;
    reason?: string;
  };
  quantumResistanceMetric?: number;
}

export interface NeuralNetworkParams {
  layers?: number;
  neurons?: number;
  activationFunction?: 'relu' | 'sigmoid' | 'tanh';
  epochs?: number;
  batchSize?: number;
}

export interface QuantumSecurityAnalysis {
  resistanceScore: number;
  vulnerabilities: string[];
  recommendations: string[];
  quantumSafeAlgorithms: string[];
}
