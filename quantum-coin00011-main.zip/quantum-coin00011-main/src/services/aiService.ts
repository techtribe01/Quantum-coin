
/**
 * Barrel file for AI services
 * This file re-exports all functionality from our modular AI services
 * to maintain backward compatibility with existing imports
 */

import aiService, { 
  generateChatResponse, 
  generateText, 
  generateQuantumCoinFunction,
  analyzeTransactionPatterns,
  trainModel,
  analyzeQuantumSecurity
} from './ai';

import type { 
  AIGenerationRequest, 
  AIGenerationResponse, 
  QuantumCoinFeature,
  ChatMessage,
  NeuralNetworkOutput,
  NeuralNetworkParams,
  QuantumSecurityAnalysis
} from './ai/types';

// Re-export the default service
export default {
  generateText,
  generateChatResponse,
  generateQuantumCoinFunction,
  analyzeTransactionPatterns,
  trainModel,
  analyzeQuantumSecurity,
  ...aiService
};

// Re-export types
export type {
  AIGenerationRequest,
  AIGenerationResponse,
  QuantumCoinFeature,
  ChatMessage,
  NeuralNetworkOutput,
  NeuralNetworkParams,
  QuantumSecurityAnalysis
};

// Re-export any named exports that components might be using
export { 
  generateChatResponse, 
  generateText, 
  generateQuantumCoinFunction,
  analyzeTransactionPatterns,
  trainModel,
  analyzeQuantumSecurity
};
