
import axios from 'axios';

// API base configuration
const API_BASE_URL = 'https://api.example.com/v1'; // Replace with actual API endpoint
const API_KEY = 'your-api-key'; // Replace with your actual API key or use env variables

// Configure axios instance
const apiClient = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
    'Authorization': `Bearer ${API_KEY}`
  }
});

// Error handling interceptor
apiClient.interceptors.response.use(
  (response) => response,
  (error) => {
    console.error('API Error:', error.response?.data || error.message);
    return Promise.reject(error);
  }
);

export default apiClient;
