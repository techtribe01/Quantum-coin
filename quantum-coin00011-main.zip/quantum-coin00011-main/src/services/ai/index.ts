
import { textGenerationService } from './textGeneration';
import { chatService } from './chatService';
import neuralNetworkService from './neuralNetworkService';
import { QuantumCoinFeature, AIGenerationResponse } from './types';

const aiService = {
  generateText: textGenerationService.generateText,
  
  generateQuantumCoinFunction: async (
    feature: QuantumCoinFeature, 
    context?: string,
    withNeuralAnalysis: boolean = false
  ): Promise<AIGenerationResponse> => {
    const response = await textGenerationService.generateText({
      prompt: `Generate information about QuantumCoin ${feature}`,
      context,
      feature,
      neuralAnalysis: withNeuralAnalysis
    });
    
    // Add neural network analysis if requested
    if (withNeuralAnalysis) {
      // Simulate transaction data for analysis
      const mockTransactions = Array(5).fill(0).map((_, i) => ({
        amount: Math.random() * 1000,
        timestamp: Date.now() - (i * 60000 * Math.random()),
        sender: `0x${Math.random().toString(16).slice(2, 12)}`,
        recipient: `0x${Math.random().toString(16).slice(2, 12)}`
      }));
      
      const neuralOutput = await neuralNetworkService.analyzeTransactionPatterns(mockTransactions);
      return {
        ...response,
        neuralOutput
      };
    }
    
    return response;
  },

  generateChatResponse: chatService.generateChatResponse,
  
  // Add neural network functions to AI service
  analyzeTransactionPatterns: neuralNetworkService.analyzeTransactionPatterns,
  trainModel: neuralNetworkService.trainModel,
  analyzeQuantumSecurity: neuralNetworkService.analyzeQuantumSecurity
};

// Export named functions for direct import
export const { generateText } = textGenerationService;
export const generateChatResponse = chatService.generateChatResponse;
export const generateQuantumCoinFunction = aiService.generateQuantumCoinFunction;
export const { 
  analyzeTransactionPatterns, 
  trainModel,
  analyzeQuantumSecurity 
} = neuralNetworkService;

export default aiService;
export * from './types';
